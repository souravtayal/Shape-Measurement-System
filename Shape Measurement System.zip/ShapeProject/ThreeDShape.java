package ShapeProject;

public abstract class ThreeDShape extends Shape {
	
	public abstract void getVolume();
		
	
	
	public abstract void getLateralSurfaceArea();
		
	
	
	public abstract void getTotalSurfaceArea();
		
	

}
