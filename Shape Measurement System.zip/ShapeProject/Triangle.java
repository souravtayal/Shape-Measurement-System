package ShapeProject;

public class Triangle extends TwoDShape
{	
     double a;
     double b;
     double c;  	

	Triangle()
	{
	}
	
	Triangle(double a,double b,double c)
	{
		this.a=a;
		this.b=b;
		this.c=c; 
	}
	
	@Override
	public void getArea()
	{
		double s=(a+b+c)/2;
		double area = Math.sqrt(s*(s-a)*(s-b)*(s-c));
	System.out.println("Area of triangle is "+area+" sq.unit");
	}
	
	@Override
	public void getPerimeter()
	{
	double perimeter = a+b+c;
	System.out.println("Perimeter of triangle is "+perimeter+" unit");
	}
}
	

