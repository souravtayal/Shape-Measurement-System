package ShapeProject;

public class Hexagon extends TwoDShape
{
  double shex;
  Hexagon()
  {
  }
  
  Hexagon(double shex) 
  {
   this.shex=shex;
  }
  
  @Override
  public void getArea()
  {
	double area=(3*Math.sqrt(3*shex*shex))/2;
	System.out.println("Area of hexagon is "+area+" sq.unit");
   }
  	
   @Override
   public void getPerimeter()
   {
   double perimeter= shex*6;
   System.out.println("Perimeter of Hexagon is "+perimeter+" unit"); 
   }
}
