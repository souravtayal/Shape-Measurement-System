package ShapeProject;

public abstract class TwoDShape extends Shape {
	
	
	public abstract void getArea();
	
	public  abstract void getPerimeter();
	
	
	
}
