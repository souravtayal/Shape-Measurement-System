package ShapeProject;

public class Cone extends ThreeDShape
{
	double n;
	double o;
	Cone()
	{
	}
	Cone(double n,double o)
	{
	this.n=n;
	this.o=o;
	}
	
	@Override
	public void getVolume()
	{
	double volume=(3.14*n*n*o)/3;
	System.out.println("Volume of cone is "+volume+"unit");
	}
	
	@Override
	public void getTotalSurfaceArea()
	{
	double z=Math.sqrt(n*n+o*o);
	double surface=3.14*n*(n+z);
	System.out.println("The Total Surface area of cone is "+surface+"unit");
	}
	
	@Override
	public void getLateralSurfaceArea()
	{
		double z=Math.sqrt(n*n+o*o);
	double surface=3.14*n*z;
	System.out.println("The Lateral Surface area of cone is "+surface+"unit");
	}

}
