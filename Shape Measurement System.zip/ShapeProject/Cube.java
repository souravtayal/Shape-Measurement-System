package ShapeProject;

public class Cube extends ThreeDShape
{
	double l;
	Cube()
	{
	}
	Cube(double l)
	{
	this.l=l;
	}
	
	@Override
	public void getVolume()
	{
	double volume=l*l*l;
	System.out.println("Volume of cone is "+volume+"unit");
	}
	
	@Override
	public void getTotalSurfaceArea()
	{
	double surface=6*l*l;
	System.out.println("The Total Surface area of cone is "+surface+"unit");
	}
	
	@Override
	public void getLateralSurfaceArea()
	{
	double lateral=4*l*l;
	System.out.println("The Lateral Surface area of cone is "+lateral+"unit");
	}

}