package ShapeProject;

public class Cylinder extends ThreeDShape
{
	double r;
	double c;
	Cylinder()
	{
	}
	Cylinder(double r,double c)
	{
	this.r=r;
	this.c=c;
	}
	
	@Override
	public void getVolume()
	{
	double volume=3.14*r*r*c;
	System.out.println("Volume of cylinder is "+volume+"unit");
	}
	
	@Override
	public void getTotalSurfaceArea()
	{
	double surface=2*3.14*r*(r+c);
	System.out.println("The Surface area of cylinder is "+surface+"unit");
	}
	
	@Override
	public void getLateralSurfaceArea()
	{
	double lateral=2*3.14*r*c;		
	System.out.println("Lateral surface area of cylinder is "+lateral+" unit");
	}
}