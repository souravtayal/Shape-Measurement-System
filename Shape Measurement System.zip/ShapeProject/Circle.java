package ShapeProject;

public class Circle extends TwoDShape
{	
     double r;

	Circle()
	{
	}
	Circle(double r)
	{
	this.r=r;
	}
	
	@Override
	public void getArea()
	{
		double area = 3.14*r*r;
	System.out.println("Area of circle is "+area+"sq.unit");
	}
	
	@Override
	public void getPerimeter()
	{
	double perimeter = 2*3.14*r;
	System.out.println("Perimeter of circle is "+perimeter+"unit");
	}
}
