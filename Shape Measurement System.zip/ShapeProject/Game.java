package ShapeProject;

import java.util.Scanner;
public class Game {
	
	Game()
	{
		System.out.println("Welcome to the Brain Trainer Game");
	}
	
	public int getSelectShape()
	{
		System.out.println("Press 1 for 2d Shapes");
		System.out.println("Press 2 for 3d Shapes");
		Scanner sc=new Scanner(System.in);
		int choice =sc.nextInt();
		switch(choice)
		{
		case 1: 
			System.out.println("You have selected 2D Shapes");
			return choice;
		case 2:
			System.out.println("You have selected 3D Shapes");
			return choice;
		default:
			System.out.println("The option is not valid pls selected valid choice");
			return getSelectShape();
			
		}
	}
	
	
	public TwoDShape twodShapes()
	{
		System.out.println("Press 1 for Circle");
		System.out.println("Press 2 for Rectangle");
		System.out.println("Press 3 for Square");
		System.out.println("Press 4 for Triangle");
		System.out.println("Press 5 for Hexagon");
		Scanner sc=new Scanner(System.in);
		int choose2d=sc.nextInt();
		switch(choose2d)
		{
		case 1:
			System.out.println("You have selected Circle");
						return  getCircle();
			
		case 2:
			System.out.println("You have selected Rectangle");
			  return getRectangle();
		case 3:
			System.out.println("You have selected Square");
			return getSquare();
			
		case 4:
			System.out.println("You have selected Triangle");
			return getTriangle();
		case 5:
			System.out.println("You have selected Hexagon");
			return getHexagon();
			default:
				System.out.println("The option is invalid pls select valid option");
				return twodShapes();
				
		}
	}
	
	public Circle getCircle()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the radius of circle");
		double r=sc.nextDouble();
		if(r>0)
		{ 
			return new Circle(r);
		}
		else
		{
			System.out.println("Enter the radius in +ve only");
			return getCircle();
		}
		
	}
	
	public Rectangle getRectangle()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the length of rectangle");
		double l=sc.nextDouble();
		System.out.println("Enter the width of rectangle");
		double w=sc.nextDouble();
		if(l>0&&w>0)
		{
		return new Rectangle(l,w);
		}
		else
		{
			System.out.println("Enter valid length and width");
			return getRectangle();
		}
	}
	
	public Square getSquare()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the side of Square");
		double  s= sc.nextDouble();
		if(s>0)
		{
		return new Square(s);
		}
		else
		{
			System.out.println("Enter valid side of square");
			return getSquare();
		}
	}
	public Triangle getTriangle()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the first side");
		int a=sc.nextInt();
		System.out.println("Enter the second side");
		int b=sc.nextInt();
		System.out.println("Enter the third side");
		int c=sc.nextInt();
		if(a+b>c&&b+c>a&&c+a>b) {
			return new Triangle(a,b,c);}
		else
		{
			System.out.println("These are not valid side's");
			return getTriangle();
		}
	}
	
	public Hexagon getHexagon()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the side of hexagon");
		double shex = sc.nextDouble();
		if(shex>0)
		{
		return new Hexagon(shex);
		}
		else
		{
			System.out.println("Enter valid side of hexagon");
			return getHexagon();
		}
	}
		
	public ThreeDShape threedShapes()
	{
		System.out.println("Press 1 for Cone");
		System.out.println("Press 2 for Cube");
		System.out.println("Press 3 for Cylinder");
		System.out.println("Press 4 for Sphere");
		System.out.println("Press 5 for Prism");
		Scanner sc=new Scanner(System.in);
		int choose3d=sc.nextInt();
		switch(choose3d)
		{
		case 1:
			System.out.println("You have selected Cone");
			return getCone();
		case 2:
			System.out.println("You have selected Cube");
			return getCube();
			
		case 3:
			System.out.println("You have selected Cylinder");
			return getCylinder();
			
		case 4:
			System.out.println("You have selected Sphere");
			return getSphere();
			
		case 5:
			System.out.println("You have selected Prism");
			return getPrism();
			
		default:
				System.out.println("The option is invalid pls select valid option");
				return threedShapes();
				
		}
	}
	
	public Cone getCone()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the radius of cone");
		double n=sc.nextDouble();
		 System.out.println("Enter the height of cone");
		 double o=sc.nextDouble();
		 if(n>0&&o>0)
		 {
		return new Cone(n,o);
		 }
		 else
		 {
			 System.out.println("Enter the valid radius and height");
			 return getCone();
		 }
	}
	
	public Cube getCube()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the side of cube");
		double l=sc.nextDouble();
		
		if(l>0){
			return new Cube(l);
			
		}
		else
		{
			System.out.println("Enter valid side of cube");
			return getCube();
		}
	}
	
	public Cylinder getCylinder()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the radius of cylinder");
		double r=sc.nextDouble();
		System.out.println("Enter the height of cylinder");
		double c=sc.nextDouble();
		if(r>0&&c>0)
		{
		return new Cylinder(r,c);
		}
		else
		{
			System.out.println("Enter valid radius and height of Cylinder");
			return getCylinder();
		}
	}
	
	public Sphere getSphere()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the radius of Sphere");
		double z=sc.nextDouble();
		if(z>0)
		{
		return new Sphere(z);
		}
		else
		{
			System.out.println("Enter valid radius of Sphere");
			return getSphere();
		}
	}
	
	public Prism getPrism()
	{
		Scanner sc=new  Scanner(System.in);
		System.out.println("Enter the length of prism");
		double lprism=sc.nextDouble();
		System.out.println("Enter the width of prism");
		double wprism=sc.nextDouble();
		System.out.println("Enter the height of prism");
		double hprism=sc.nextDouble();
		if(lprism>0&&wprism>0&&hprism>0)
		{
		return new Prism(lprism,wprism,hprism);
		}
		else
		{
			System.out.println("Enter valid length,width,height of Prism");
			return getPrism();
		}
	}
	
	
	
}
