package ShapeProject;

public class Square extends TwoDShape
{
	double s;
	Square()
	{
	}
	Square(double s)
	{
	this.s=s;
	}
	
	@Override
	public void getArea()
	{
	double area = s*s;
	System.out.println("Area of square is "+area+"sq.unit");
	}
	
	@Override
	public void getPerimeter()
	{
	double perimeter =4*s;
	System.out.println("Perimeter of Square is "+perimeter+"unit");
	}
}	
