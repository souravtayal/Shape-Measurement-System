package ShapeProject;

public class Sphere extends ThreeDShape
{
	double z;
	Sphere()
	{
	}
	Sphere(double z)
	{
	this.z=z;
	}
	
	@Override
	public void getVolume()
	{
	double volume=(4/3)*3.14*z*z*z;
	System.out.println("Volume of Sphere is "+volume+"unit");
	}
	
	@Override
	public void getTotalSurfaceArea()
	{
	double surface=4*3.14*z*z;
	System.out.println("The Surface area of sphere is "+surface+"unit");
	}
	
	@Override
	public void getLateralSurfaceArea()
	{
	double lateral=4*3.14*z*z;
	System.out.println("The Surface area of sphere is "+lateral+"unit");
	}

}

