package ShapeProject;

public class Rectangle extends TwoDShape
{	
     double l;
     double w;  	

	Rectangle()
	{
	}
	Rectangle(double l,double w)
	{
	this.l=l;
	this.w=w;
	}
	
	@Override
	public void getArea()
	{
		double area = l*w;
	System.out.println("Area of rectangle is "+area+"sq.unit");
	}
	
	@Override
	public void getPerimeter()
	{
	double perimeter = 2*(l+w);
	System.out.println("Perimeter of rectangle is "+perimeter+"unit");
	}
}