package ShapeProject;

public class Prism extends ThreeDShape{
	
	double lprism;
	double wprism;
	double hprism;

	Prism()
	{
		
	}
	Prism(double lprism,double wprism,double hprism)
	{
		this.lprism=lprism;
		this.wprism=wprism;
		this.hprism=hprism;
	}
	
	@Override
	public void  getVolume()
	{
		double basearea=lprism*wprism;
		double volume= basearea*hprism;
		System.out.println("Volume of prism is :"+volume+"unit");
	}
	
	@Override
	public void getTotalSurfaceArea()
	{
		double bse=lprism*wprism;
		double lateral = (2*(lprism+wprism))*hprism;
		double totalsurface= 2*bse + lateral;
		
		System.out.println("Total surface area of prism is :"+totalsurface+"unit");
		
	}
	
	@Override
	public void getLateralSurfaceArea()
	{
		double perimeter=2*(lprism+wprism);
		double lateralsurface= perimeter*hprism;
		System.out.println("Lateral surface area of prism is :"+lateralsurface+"unit");
	}
}
