package ShapeProject;

import java.util.Scanner;
public class User {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Game g=new Game();
		char c;
		do {
		int choice = g.getSelectShape();
		
		if(choice==1)
		{
		TwoDShape t1= g.twodShapes();
		t1.getArea();
		t1.getPerimeter();
		}
		else {
		ThreeDShape t2= g.threedShapes();
		t2.getVolume();
		t2.getTotalSurfaceArea();
		t2.getLateralSurfaceArea();
		}
		
		System.out.println("If u want to continue press y/Y");
		c=sc.next().charAt(0);
		
		}while(c=='y'||c=='Y');
		System.out.println("Thank you for playing the game...!");
	}
}
